# Changelog

## 1.0.1 — 2025-08-23
- Initial release of Bulk Add Products module
- Add multiple product/service lines on customer and supplier documents
- AJAX add row + save all functionality
- CKEditor/FCKEditor description support
- Dolibarr v17–22 compatibility

## 1.0.2 — 2025-08-26
- Update module and description